let DATA = null;
let selectedBonus = null;

const TYPE_COLORS = {};

function slotMax(slotId) {
    const s = DATA.slot_types.find(s => s.id === slotId);
    return s ? s.max : 1;
}

function slotLabel(slotId) {
    const s = DATA.slot_types.find(s => s.id === slotId);
    return s ? s.label : slotId;
}

function typeLabel(type) {
    const t = DATA.types[type];
    return t ? t.label : type;
}

function typeTagStyle(type) {
    const t = DATA.types[type];
    return t ? t.tag_style : { background: '#222', color: '#aaa' };
}

/* ── BONUS TYPE HELPERS ── */
function getBonusType(bonusId) {
    return DATA.bonus_types.find(b => b.id === bonusId);
}

// Returns unit string for a given bonus + unit_type
function unitFor(bonusId, unitType) {
    const bt = getBonusType(bonusId);
    if (!bt || !bt.units) return '';
    const ut = unitType || 'flat';
    return bt.units[ut] || bt.units.flat || '';
}

// Returns true if bonus has more than one unit type defined
function bonusIsMixed(bonusId) {
    const bt = getBonusType(bonusId);
    if (!bt || !bt.units) return false;
    return Object.keys(bt.units).length > 1;
}

function formatVal(value, unit, unitType) {
    if (unitType === 'multiplier') {
        return '×' + value + ' ' + unit;
    }
    return '+' + value + ' ' + unit;
}

/* ── TIERS ── */
// Generate tier rows from a formula definition
function generateTierRows(formula, bonusId) {
    const rows = [];
    if (formula.type === 'linear') {
        for (let i = 1; i <= formula.max_tier; i++) {
            const val = formula.init + (i - 1) * formula.coeff;
            const row = { label: (formula.label_prefix || 'Tier') + ' ' + i };
            row[bonusId] = val;
            rows.push(row);
        }
    }
    return rows;
}

// Get tier rows for a source, either from tiers array or formula
function getTierRows(src, bonusId) {
    if (src.tiers_formula) {
        return generateTierRows(src.tiers_formula, bonusId);
    }
    if (src.tiers) {
        return src.tiers;
    }
    return null;
}

/* ── DROPDOWN ── */
function buildDropdown(filter) {
    const opts = document.getElementById('bonus-options');
    opts.innerHTML = '';
    const q = (filter || '').toLowerCase();
    for (const bt of DATA.bonus_types) {
        if (q && !bt.label.toLowerCase().includes(q)) continue;
        const opt = document.createElement('div');
        opt.className = 'bonus-option' + (selectedBonus === bt.id ? ' selected' : '');
        opt.textContent = bt.label;
        opt.addEventListener('click', () => {
            selectBonus(bt.id);
            closeDropdown();
        });
        opts.appendChild(opt);
    }
}

function openDropdown() {
    document.getElementById('bonus-select-box').classList.add('open');
    document.getElementById('bonus-dropdown').classList.add('open');
    document.getElementById('bonus-search').value = '';
    buildDropdown('');
    setTimeout(() => document.getElementById('bonus-search').focus(), 50);
}

function closeDropdown() {
    document.getElementById('bonus-select-box').classList.remove('open');
    document.getElementById('bonus-dropdown').classList.remove('open');
}

/* ── RENDER ── */
function selectBonus(id) {
    selectedBonus = id;
    const bt = getBonusType(id);
    const lbl = document.getElementById('bonus-select-label');
    lbl.textContent = bt.label;
    lbl.classList.remove('placeholder');
    history.replaceState(null, '', '?bonus=' + encodeURIComponent(id));
    renderContent();
}

// Get all bonus entries for a source matching the selected bonus id
function getMatchingBonuses(src, bonusId) {
    return src.bonuses.filter(b => b.bonus === bonusId);
}

function renderContent() {
    const content = document.getElementById('bonus-content');
    const empty = document.getElementById('empty-state');
    content.innerHTML = '';

    if (!selectedBonus) {
        content.classList.remove('visible');
        empty.style.display = '';
        return;
    }

    empty.style.display = 'none';
    content.classList.add('visible');

    // Group sources by type that have this bonus (may have multiple entries)
    const groups = {};
    for (const src of DATA.sources) {
        const matchingBonuses = getMatchingBonuses(src, selectedBonus);
        if (matchingBonuses.length === 0) continue;
        if (!groups[src.type]) groups[src.type] = [];
        groups[src.type].push({ src, bonuses: matchingBonuses });
    }

    renderMaxPills(content, groups);

    const typeOrder = Object.keys(DATA.types);

    for (const type of typeOrder) {
        if (!groups[type]) continue;
        const section = document.createElement('div');
        section.className = 'source-section';

        const hdr = document.createElement('div');
        hdr.className = 'section-header';
        hdr.textContent = typeLabel(type) + 's';
        section.appendChild(hdr);

        for (const { src, bonuses } of groups[type]) {
            const row = document.createElement('div');
            row.className = 'source-row';

            // image
            const imgWrap = document.createElement('div');
            imgWrap.className = 'src-img';
            if (src.image) {
                const img = document.createElement('img');
                img.src = src.image;
                img.alt = src.name;
                img.onerror = () => { imgWrap.innerHTML = '<div class="src-img-ph"></div>'; };
                imgWrap.appendChild(img);
            } else {
                imgWrap.innerHTML = '<div class="src-img-ph"></div>';
            }

            // info
            const info = document.createElement('div');
            info.className = 'src-info';
            const name = document.createElement('div');
            name.className = 'src-name';
            name.textContent = src.name;
            info.appendChild(name);

            const tags = document.createElement('div');
            tags.className = 'src-tags';

            const typeTag = document.createElement('span');
            typeTag.className = 'tag';
            const ts = typeTagStyle(type);
            typeTag.style.background = ts.background;
            typeTag.style.color = ts.color;
            typeTag.textContent = typeLabel(type) + (src.slot ? ' · ' + slotLabel(src.slot) : '');
            tags.appendChild(typeTag);

            if (src.available === false) {
                const naTag = document.createElement('span');
                naTag.className = 'tag tag-na';
                naTag.textContent = 'Unavailable';
                tags.appendChild(naTag);
            }

            info.appendChild(tags);

            // right — stack all matching bonus values
            const right = document.createElement('div');
            right.className = 'src-right';

            const val = document.createElement('div');
            val.className = 'src-val';
            val.innerHTML = bonuses.map(b => {
                const ut = b.unit_type || 'flat';
                const u = unitFor(selectedBonus, ut);
                return formatVal(b.value, u, ut);
            }).join('<br>');
            right.appendChild(val);

            if (src.slot) {
                const max = slotMax(src.slot);
                const slots = document.createElement('div');
                slots.className = 'src-slots';
                slots.textContent = max > 1 ? 'up to ' + max + ' slots' : '1 slot';
                right.appendChild(slots);
            }

            row.append(imgWrap, info, right);

            const wrapper = document.createElement('div');
            wrapper.className = 'source-row-wrap';
            wrapper.appendChild(row);

            // Detail table — show tiers for the first matching bonus (or all bonuses if multiple)
            const tierRows = getTierRows(src, selectedBonus);
            if (tierRows) {
                wrapper.classList.add('has-detail');

                const table = document.createElement('div');
                table.className = 'detail-table';

                for (const tier of tierRows) {
                    const tr = document.createElement('div');
                    tr.className = 'detail-row';
                    const lbl = document.createElement('span');
                    lbl.className = 'detail-lbl';
                    lbl.textContent = tier.label;
                    tr.appendChild(lbl);

                    // Show a cell for each matching bonus unit type
                    for (const b of bonuses) {
                        const ut = b.unit_type || 'flat';
                        const cell = document.createElement('span');
                        cell.className = 'detail-val';
                        const tierVal = tier[selectedBonus];
                        cell.textContent = tierVal != null
                            ? formatVal(tierVal, unitFor(selectedBonus, ut), ut)
                            : '—';
                        tr.appendChild(cell);
                    }

                    table.appendChild(tr);
                }

                wrapper.appendChild(table);

                const chev = document.createElement('span');
                chev.className = 'src-chev';
                chev.textContent = '▼';
                right.appendChild(chev);

                row.addEventListener('click', () => {
                    const isOpen = table.classList.contains('open');
                    table.classList.toggle('open', !isOpen);
                    chev.style.transform = isOpen ? '' : 'rotate(180deg)';
                });
            }

            section.appendChild(wrapper);
        }

        content.appendChild(section);
    }
}

/* ── MAX PILLS ── */
function compoundTotal(items, bonusId) {
    // Each item: { value, unit_type, mult }
    // Compound formula: sum(flat) × (1 + sum(percent)/100) × product(multipliers)
    // mult is the slot multiplier (how many of this source can be equipped)
    let flat = 0, percent = 0, multiplier = 1;
    let hasMixed = false;
    const unitTypes = new Set(items.map(i => i.unit_type || 'flat'));
    hasMixed = unitTypes.size > 1;

    for (const item of items) {
        const ut = item.unit_type || 'flat';
        const total = item.value * item.mult;
        if (ut === 'flat') flat += total;
        else if (ut === 'percent') percent += total;
        else if (ut === 'multiplier') multiplier *= (1 + total / 100);
    }

    if (hasMixed) {
        // Compound result — return as flat ATK equivalent
        return { value: flat * (1 + percent / 100) * multiplier, unit_type: 'flat', isMixed: true };
    } else {
        // All same type — just sum
        const ut = [...unitTypes][0];
        const sum = ut === 'flat' ? flat : ut === 'percent' ? percent : multiplier - 1;
        return { value: ut === 'multiplier' ? (multiplier - 1) * 100 : (ut === 'flat' ? flat : percent), unit_type: ut, isMixed: false };
    }
}

function formatTotal(result, bonusId) {
    const ut = result.unit_type || 'flat';
    const u = unitFor(bonusId, ut);
    if (result.isMixed) {
        return formatVal(Math.round(result.value * 10) / 10, u, 'flat') + ' (combined)';
    }
    return formatVal(Math.round(result.value * 10) / 10, u, ut);
}

function renderMaxPills(content, groups) {
    function calcItems(availableOnly) {
        const slotBest = {};   // slot → { bonuses: [{value, unit_type}], mult }
        const items = [];

        for (const type of Object.keys(DATA.types)) {
            if (!groups[type]) continue;
            for (const { src, bonuses } of groups[type]) {
                if (availableOnly && src.available === false) continue;

                for (const b of bonuses) {
                    const entry = { src, value: b.value, unit_type: b.unit_type || 'flat', mult: 1 };

                    if (src.slot) {
                        const max = slotMax(src.slot);
                        if (max === 1) {
                            // Keep best per slot per unit_type
                            const key = src.slot + ':' + entry.unit_type;
                            if (!slotBest[key] || b.value > slotBest[key].value) {
                                slotBest[key] = entry;
                            }
                        } else {
                            items.push({ ...entry, mult: max });
                        }
                    } else {
                        items.push(entry);
                    }
                }
            }
        }

        for (const s of Object.values(slotBest)) items.push(s);
        return items;
    }

    const allItems = calcItems(false);
    const availItems = calcItems(true);

    const allResult = compoundTotal(allItems, selectedBonus);
    const availResult = compoundTotal(availItems, selectedBonus);

    const maxSection = document.createElement('div');
    maxSection.className = 'max-section';

    function makePill(label, result, items, pillId) {
        const pill = document.createElement('div');
        pill.className = 'max-pill';
        pill.id = pillId;

        const top = document.createElement('div');
        top.className = 'max-pill-top';

        const left = document.createElement('div');
        const lbl = document.createElement('div');
        lbl.className = 'max-pill-lbl';
        lbl.textContent = label;
        const val = document.createElement('div');
        val.className = 'max-pill-val';
        val.textContent = formatTotal(result, selectedBonus);
        left.append(lbl, val);

        const chev = document.createElement('span');
        chev.className = 'max-pill-chevron';
        chev.textContent = '▼';

        top.append(left, chev);
        pill.appendChild(top);

        const bd = document.createElement('div');
        bd.className = 'breakdown';

        for (const item of items) {
            const row = document.createElement('div');
            row.className = 'bd-row';
            const nameEl = document.createElement('div');
            nameEl.className = 'bd-name';
            const dot = document.createElement('span');
            dot.className = 'bd-dot';
            dot.style.background = TYPE_COLORS[item.src.type] || '#888';
            const txt = document.createElement('span');
            const ut = item.unit_type || 'flat';
            const u = unitFor(selectedBonus, ut);
            let nameText = item.src.name + (item.mult > 1 ? ' ×' + item.mult : '');
            if (item.src.available === false) {
                txt.style.color = '#d04040';
                nameText += ' (unavail.)';
            }
            txt.textContent = nameText;
            nameEl.append(dot, txt);
            const valEl = document.createElement('div');
            valEl.className = 'bd-val';
            valEl.textContent = formatVal(item.value * item.mult, u, ut);
            row.append(nameEl, valEl);
            bd.appendChild(row);
        }

        const totalRow = document.createElement('div');
        totalRow.className = 'bd-total';
        totalRow.innerHTML = '<span>Total</span><span>' + formatTotal(result, selectedBonus) + '</span>';
        bd.appendChild(totalRow);
        pill.appendChild(bd);

        return pill;
    }

    maxSection.appendChild(makePill('Max (all sources)', allResult, allItems, 'pill-all'));
    maxSection.appendChild(makePill('Max (available only)', availResult, availItems, 'pill-avail'));
    content.appendChild(maxSection);

    const pills = maxSection.querySelectorAll('.max-pill');
    pills.forEach(pill => {
        pill.addEventListener('click', () => {
            const isOpen = pill.querySelector('.breakdown').classList.contains('open');
            pills.forEach(p => {
                p.querySelector('.breakdown').classList.toggle('open', !isOpen);
                p.classList.toggle('open', !isOpen);
            });
        });
    });
}

/* ── INIT ── */
async function init() {
    try {
        const r = await fetch('bonuses.json');
        DATA = await r.json();
        const sourceArrays = await Promise.all(
            DATA.source_files.map(f => fetch(f).then(r => r.json()))
        );
        DATA.sources = sourceArrays.flat();
    } catch {
        document.body.innerHTML = '<p style="color:#f88;padding:2rem;font-size:16px">Could not load bonuses.json</p>';
        return;
    }

    // Build TYPE_COLORS from JSON for breakdown dots
    for (const [type, def] of Object.entries(DATA.types)) {
        TYPE_COLORS[type] = def.tag_style ? def.tag_style.color : '#888';
    }

    const params = new URLSearchParams(window.location.search);
    const bonusParam = params.get('bonus');
    if (bonusParam && DATA.bonus_types.find(b => b.id === bonusParam)) {
        selectBonus(bonusParam);
    }

    // Dropdown toggle
    document.getElementById('bonus-select-box').addEventListener('click', (e) => {
        e.stopPropagation();
        const isOpen = document.getElementById('bonus-dropdown').classList.contains('open');
        isOpen ? closeDropdown() : openDropdown();
    });

    document.getElementById('bonus-dropdown').addEventListener('click', e => e.stopPropagation());
    document.addEventListener('click', closeDropdown);

    document.getElementById('bonus-search').addEventListener('input', (e) => {
        buildDropdown(e.target.value);
    });

    document.getElementById('report-btn').addEventListener('click', (e) => {
        e.currentTarget.href = `https://github.com/badbotexe/evi/issues/new?title=${encodeURIComponent('[Bonuses] Issue')}&body=${encodeURIComponent('**Bonus:** ' + (selectedBonus ?? 'N/A') + '\n\n**Description:**\n')}`;
    });

    buildDropdown('');
}

init();
